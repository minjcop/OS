#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[]){
	int pid;
	int nice;

	if(argc < 3){ // ?
		return -1;
	}
	pid = atoi(argv[1]);
	nice = atoi(argv[2]);
	if(nice < 0 || nice > 40){
		printf(2, "Invalid!! nice_value range : 0 ~ 40\n");
		return -1;
	}
	printf(1, "pid = %d, nice_value = %d\n", pid, nice);
	setnice(pid, nice);
	return 0;
}
